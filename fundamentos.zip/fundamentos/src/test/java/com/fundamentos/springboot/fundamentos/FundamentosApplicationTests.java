package com.fundamentos.springboot.fundamentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
